Open source/project.fzz in Fritzing. The archive contains its custom components.
The source/project.fz alone requires importing source/parts/*.fzpz first.
Native rendered views and manufacturing exports are in exports/.
No native DRC or electrical ERC was run; inspect the design before fabrication.
Recreate with engineering-codex-environment examples/fritzing/led-series.json.
